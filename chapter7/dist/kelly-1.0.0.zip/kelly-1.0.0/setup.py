from distutils.core import setup

setup( 
        name         = 'kelly', 
        version      = '1.0.0', 
        ## TODO: be sure to change these next few lines to match your details!
        py_modules   = ['kelly5', 'kelly6'],
        author       = 'kevin',
        author_email = 'kevin@gmail.com',
        url          = 'http://www.kevin.com',
        description  = '',
     )